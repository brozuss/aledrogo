  <!-- Footer -->
<footer>

  <ul>
    <li><a href="../main/home.php">STRONA GŁÓWNA</a></li>
    <li><a href="">O NAS</a></li>
    <li><a href="mailto:alledrogo@gmail.com">SKONTAKTUJ SIĘ Z NAMI</a></li>
  </ul>

</footer>
      
</body>

</html>