<!-- head & navbar -->
<?php
include('static/head.php');
include('static/navbar.php');
?>
<!-- main index -->



<!-- footer -->
<?php
include('static/footer.php');
?>