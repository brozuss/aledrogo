<?php
    $db_host = "localhost";
    $db_name = "kbro2";
    $db_user = "root";
    $db_pass = "";
    $connect = new mysqli($db_host,$db_user,$db_pass,$db_name);
?>
